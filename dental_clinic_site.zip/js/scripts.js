function handleForm(e){
  e.preventDefault();
  const form = e.target;
  const data = Object.fromEntries(new FormData(form).entries());
  alert('Заявка отправлена:\n' + JSON.stringify(data, null, 2) + '\n(Форма пример — интегрируйте с сервером для реальной отправки)');
  form.reset();
  return false;
}
document.getElementById('bookBtn')?.addEventListener('click', ()=>{
  document.getElementById('bookingForm')?.scrollIntoView({behavior:'smooth'});
});
